<?php
    date_default_timezone_set('Asia/Kolkata');
    $dt= date('d-m-Y ');
    echo $dt;
?>